import express from 'express';
import cors from 'cors';
import dotenv from 'dotenv';
import authRoutes from './routes/auth.js';
import companyRoutes from './routes/company.js';
import multer from 'multer';
import roleRoutes from './routes/roleRoutes.js';
import path from 'path';
import logoRoutes from './routes/logo.js'; // Import the logo.js route
import emailRoutes from './routes/mailsender.js';


import { errorHandler } from './middleware/errorHandler.js';

dotenv.config();

const app = express();
const PORT = process.env.PORT || 5000;

// Multer setup for form-data
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, 'C:/Users/kmlro/Downloads/abmmm');
    },
    filename: (req, file, cb) => {
        cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
    }
});
const upload = multer({ storage: storage });

// Middleware
app.use(cors());
app.use(express.json());
app.use(express.urlencoded({ extended: true }));

// Routes
app.use('/api/auth', authRoutes);
app.use('/api', companyRoutes); 
app.use('/api/logo', logoRoutes);
app.use('/api', upload.none(), roleRoutes);
app.use('/uploads', express.static('C:/Users/kmlro/Downloads/abmmm'));
app.use('/api/email', emailRoutes);

// Error handling
app.use(errorHandler);

app.listen(PORT, () => {
  console.log(`Server running on port ${PORT}`);
});
