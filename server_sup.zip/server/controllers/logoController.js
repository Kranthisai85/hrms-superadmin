import path from 'path';

export const uploadLogo = (req, res) => {
    try {
        if (!req.file) {
            return res.status(400).json({ error: 'No file uploaded' });
        }

        // Define the base URL for uploaded files
        const baseUrl = 'https://pacehrm.com/uploads/logos';

        res.json({
            message: 'File uploaded successfully',
            filePath: path.join(req.file.destination, req.file.filename),
            fileUrl: `${baseUrl}/${req.file.filename}` // Construct the public URL
        });
    } catch (error) {
        res.status(500).json({ error: error.message });
    }
};