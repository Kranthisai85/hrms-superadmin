import express from 'express';
import { uploadLogo } from '../controllers/logoController.js';
import multer from 'multer';
import fs from 'fs';
import path from 'path';

// Define upload directory (Windows path)
const uploadPath = 'C:/Users/kmlro/Downloads/abmmm';

// Ensure the upload directory exists
if (!fs.existsSync(uploadPath)) {
    fs.mkdirSync(uploadPath, { recursive: true });
}

// Configure Multer storage
const storage = multer.diskStorage({
    destination: (req, file, cb) => {
        cb(null, uploadPath);
    },
    filename: (req, file, cb) => {
        // cb(null, file.fieldname + '-' + Date.now() + path.extname(file.originalname));
        cb(null, file.originalname); // Use the original file name

    }
});

// Initialize Multer
const upload = multer({
    storage: storage,
    limits: { fileSize: 5 * 1024 * 1024 }, // Limit file size to 5MB
});

const router = express.Router();

// Route for single file upload
router.post('/', upload.single('file'), uploadLogo);

export default router;